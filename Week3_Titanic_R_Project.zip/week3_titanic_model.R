# WEEK 3: Statistical Analysis and Predictive Modeling
# Dataset: Titanic (public seaborn-data CSV)
# Outcome: survived (0 = No, 1 = Yes)
# Run in RStudio. The script saves tables, metrics, and plots in week3_outputs/.

# 1. Packages ---------------------------------------------------------------
packages <- c("ggplot2", "caret", "pROC", "car", "dplyr")
missing_packages <- packages[!packages %in% rownames(installed.packages())]
if (length(missing_packages) > 0) install.packages(missing_packages)

library(ggplot2)
library(caret)
library(pROC)
library(car)
library(dplyr)

set.seed(123)
dir.create("week3_outputs", showWarnings = FALSE)

# 2. Load public dataset ----------------------------------------------------
data_url <- "https://raw.githubusercontent.com/mwaskom/seaborn-data/master/titanic.csv"
titanic <- read.csv(data_url, stringsAsFactors = FALSE)

cat("Dataset dimensions:", dim(titanic), "\n")
cat("\nStructure:\n")
str(titanic)
cat("\nSummary:\n")
print(summary(titanic))
write.csv(summary(as.data.frame(lapply(titanic, function(x) if(is.numeric(x)) x else as.numeric(as.factor(x))))),
          "week3_outputs/summary_numeric.csv", row.names = FALSE)

# 3. Select variables and clean data ---------------------------------------
# Exclude 'alive' because it directly duplicates the target 'survived'.
# Exclude high-missingness 'deck' and redundant 'embark_town'.
dat <- titanic[, c("survived", "pclass", "sex", "age", "sibsp", "parch", "fare", "embarked")]
dat$age[is.na(dat$age)] <- median(dat$age, na.rm = TRUE)
mode_value <- names(sort(table(dat$embarked), decreasing = TRUE))[1]
dat$embarked[is.na(dat$embarked) | dat$embarked == ""] <- mode_value

dat$survived <- factor(dat$survived, levels = c(0, 1), labels = c("No", "Yes"))
dat$pclass <- factor(dat$pclass)
dat$sex <- factor(dat$sex)
dat$embarked <- factor(dat$embarked)
dat <- na.omit(dat)

cat("\nCleaned dimensions:", dim(dat), "\n")
cat("\nMissing values after cleaning:\n")
print(colSums(is.na(dat)))

# 4. Exploratory statistical analysis --------------------------------------
cat("\nSurvival counts:\n")
print(table(dat$survived))
cat("\nSurvival proportion:\n")
print(prop.table(table(dat$survived)))

# Hypothesis 1: survival is independent of sex.
# H0: Sex and survival are independent. H1: They are associated.
sex_tab <- table(dat$sex, dat$survived)
chi_sex <- chisq.test(sex_tab)
cat("\nChi-square test: sex vs survival\n")
print(chi_sex)

# Hypothesis 2: mean age is equal in survivors and non-survivors.
# H0: Mean age is equal. H1: Mean age differs.
age_test <- t.test(age ~ survived, data = dat)
cat("\nWelch two-sample t-test: age by survival\n")
print(age_test)

# Distribution and normality checks (normality is not required for logistic
# regression predictors; this is descriptive exploration only).
shapiro_sample <- shapiro.test(sample(dat$age, min(5000, nrow(dat))))
cat("\nShapiro-Wilk test for age (sample):\n")
print(shapiro_sample)

# Correlation among numeric predictors (Spearman is robust to non-normality).
numeric_vars <- dat[, c("age", "sibsp", "parch", "fare")]
spearman_cor <- cor(numeric_vars, method = "spearman", use = "complete.obs")
cat("\nSpearman correlation matrix:\n")
print(round(spearman_cor, 3))
write.csv(round(spearman_cor, 3), "week3_outputs/spearman_correlations.csv")

# Save statistical test summaries
capture.output(chi_sex, age_test, shapiro_sample,
               file = "week3_outputs/hypothesis_tests.txt")

# 5. Visualizations ---------------------------------------------------------
p1 <- ggplot(dat, aes(x = sex, fill = survived)) +
  geom_bar(position = "fill") +
  labs(title = "Survival proportion by sex", x = "Sex", y = "Proportion", fill = "Survived") +
  theme_minimal()
ggsave("week3_outputs/survival_by_sex.png", p1, width = 7, height = 5)

p2 <- ggplot(dat, aes(x = age, fill = survived)) +
  geom_histogram(bins = 30, alpha = 0.65, position = "identity") +
  labs(title = "Age distribution by survival", x = "Age", y = "Count") +
  theme_minimal()
ggsave("week3_outputs/age_distribution.png", p2, width = 7, height = 5)

p3 <- ggplot(dat, aes(x = fare, y = age, colour = survived)) +
  geom_point(alpha = 0.5) +
  labs(title = "Fare and age by survival", x = "Fare", y = "Age", colour = "Survived") +
  theme_minimal()
ggsave("week3_outputs/fare_age_scatter.png", p3, width = 7, height = 5)

# 6. Train/test split and 5-fold cross-validation --------------------------
# Stratified split preserves the outcome proportions in both sets.
set.seed(123)
train_index <- createDataPartition(dat$survived, p = 0.80, list = FALSE)
train_data <- dat[train_index, ]
test_data <- dat[-train_index, ]

ctrl <- trainControl(
  method = "cv",
  number = 5,
  classProbs = TRUE,
  summaryFunction = twoClassSummary,
  savePredictions = "final"
)

# Logistic regression. "Yes" is the positive class (first level for caret).
train_data$survived <- relevel(train_data$survived, ref = "Yes")
test_data$survived <- relevel(test_data$survived, ref = "Yes")

set.seed(123)
model <- train(
  survived ~ pclass + sex + age + sibsp + parch + fare + embarked,
  data = train_data,
  method = "glm",
  family = binomial(),
  trControl = ctrl,
  metric = "ROC"
)

cat("\nCross-validation model results:\n")
print(model)
cat("\nFinal logistic regression coefficients:\n")
print(summary(model$finalModel))

# 7. Test-set predictions and performance ---------------------------------
prob_yes <- predict(model, newdata = test_data, type = "prob")[, "Yes"]
pred_class <- ifelse(prob_yes >= 0.50, "Yes", "No")
pred_class <- factor(pred_class, levels = c("Yes", "No"))
actual <- factor(test_data$survived, levels = c("Yes", "No"))

cm <- confusionMatrix(data = pred_class, reference = actual, positive = "Yes")
roc_obj <- roc(response = actual, predictor = prob_yes, levels = c("No", "Yes"), direction = "<")
auc_value <- as.numeric(auc(roc_obj))

cat("\nTest-set confusion matrix and metrics:\n")
print(cm)
cat("\nTest-set ROC-AUC:", round(auc_value, 4), "\n")

metrics <- data.frame(
  Metric = c("Accuracy", "Kappa", "Sensitivity / Recall", "Specificity", "Precision", "F1", "ROC-AUC"),
  Value = c(
    unname(cm$overall["Accuracy"]),
    unname(cm$overall["Kappa"]),
    unname(cm$byClass["Sensitivity"]),
    unname(cm$byClass["Specificity"]),
    unname(cm$byClass["Pos Pred Value"]),
    unname(cm$byClass["F1"]),
    auc_value
  )
)
write.csv(metrics, "week3_outputs/test_metrics.csv", row.names = FALSE)
write.csv(as.data.frame.matrix(cm$table), "week3_outputs/confusion_matrix.csv")

# ROC curve
png("week3_outputs/roc_curve.png", width = 900, height = 650)
plot(roc_obj, main = paste("ROC Curve (AUC =", round(auc_value, 3), ")"))
dev.off()

# 8. Diagnostics ------------------------------------------------------------
# Multicollinearity: VIF on a corresponding linear-model design.
vif_model <- lm(as.numeric(survived == "Yes") ~ pclass + sex + age + sibsp + parch + fare + embarked,
                data = train_data)
vif_values <- car::vif(vif_model)
cat("\nVIF values (screening for multicollinearity):\n")
print(vif_values)
capture.output(vif_values, file = "week3_outputs/vif_diagnostics.txt")

# Calibration-style plot: observed survival rate by predicted probability bins.
calibration_data <- data.frame(probability = prob_yes, actual = actual)
calibration_data$group <- cut(calibration_data$probability,
                              breaks = quantile(calibration_data$probability,
                                                probs = seq(0, 1, 0.1),
                                                na.rm = TRUE),
                              include.lowest = TRUE)
calibration <- aggregate(as.numeric(actual == "Yes") ~ group,
                         data = calibration_data, FUN = mean)
names(calibration)[2] <- "observed_survival_rate"
write.csv(calibration, "week3_outputs/calibration_by_decile.csv", row.names = FALSE)

# Export reproducibility details
capture.output(sessionInfo(), file = "week3_outputs/session_info.txt")
cat("\nCompleted. See the week3_outputs folder for plots, metrics, and diagnostics.\n")
